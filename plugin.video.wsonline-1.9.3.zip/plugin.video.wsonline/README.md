# plugin.video.wsonline
##Kodi/XBMC Addon for Watchseries-Online

Part of my Kodi/XBMC Addon's Repo which can be found here

##[http://github.com/moedje/kodi-repo-gaymods]

###[https://github.com/moedje/kodi-repo-gaymods/blob/master/plugin.video.wsonline/]